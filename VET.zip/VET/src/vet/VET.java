/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vet;

import java.util.Scanner;

/**
 *
 * @author Maria Gabriela
 */
public class VET {

    public static void mostrar(){
        System.out.println("===== 🐾Resumen del día⭐⭐⭐⭐ =====");
        System.out.println(" ");
        System.out.println("Bañados realizados: "+bancantidad);
        System.out.println("Consultas médicas realizadas: "+concantidad);
        System.out.println("Otros serviciones realizados: "+ocantidad);
        System.out.println("Animales pequeños atendidos: "+scantidad);
        System.out.println("Animales medianos atendidos: "+mcantidad);
        System.out.println("Animales grandes atendidos: "+bcantidad);
    }
    
    public static servicio datos=new servicio();
    public static void main(String[] args) {
        double total=0;
        double precio[]=new double[9];
        precio[0]=150;
        precio[1]=300;
        precio[2]=500;
        precio[3]=200;
        precio[4]=400;
        precio[5]=600;
        precio[6]=100;
        precio[7]=200;
        precio[8]=300;

        
        Scanner entrada=new Scanner(System.in);
        int opcion;
        int bancantidad=0;
        int concantidad=0;
        int ocantidad=0;
        String servicio,especie;
        
        System.out.println("==== 🐾🎀 Bienvenido a la Veterinaria M&C 🎀🐾 ====");
       while(true){
           System.out.println("Que desea realizar?\n"
                   + "1.Inicializar Servicio\n"
                   + "2.Cerrar Caja");
           System.out.println("Ingrese una opción: ");
           opcion=entrada.nextInt();
           switch(opcion){
               case 1:
                   System.out.println("==== Has elegido inicializar servicio 🐶 ====");
                   System.out.println("");
                   System.out.println("Que servicio desea realizar?\n"
                           + "Bañado\n"
                           + "Consulta medica\n"
                           + "Otro");
                   servicio=entrada.next();
                   switch(servicio){
                       case "Bañado":
                       bancantidad++;
                           System.out.println("=== Servicio de bañado ha sido selecionado ===");
                           System.out.println("Que especie es su mascota?\n"
                                   + "1.Perro\n"
                                   + "2.Gato\n"
                                   + "3.Conejo\n"
                                   + "4.Animal exotico");
                   especie= entrada.next();
                    System.out.println("¿Cuál es el tamaño de su mascota? (pequeño, mediano, grande)");
                    String tamano = entrada.nextLine();
                           break;
                       case "Consulta medica":
                       concantidad++;
                           System.out.println("=== Servicio de Consulta médica ha sido selecionado ===");
                           System.out.println("Que especie es su mascota?\n"
                                   + "1.Perro\n"
                                   + "2.Gato\n"
                                   + "3.Conejo\n"
                                   + "4.Animal exotico");
                   especie= entrada.next();
                   System.out.println("¿Cuál es el tamaño de su mascota? (pequeño, mediano, grande)");
                   tamano = entrada.nextLine();
                    
                           break;
                       case "Otro":
                       ocantidad++;
                           System.out.println("=== Otro servicio ha sido seleccionado. Ingrese que desea realizar. ===");
                           String otro= entrada.next();
                           System.out.println("Que especie es su mascota?\n"
                                   + "1.Perro\n"
                                   + "2.Gato\n"
                                   + "3.Conejo\n"
                                   + "4.Animal exotico");
                   especie= entrada.next();
                        System.out.println("¿Cuál es el tamaño de su mascota? (pequeño, mediano, grande)");
                   tamano = entrada.nextLine();
                   break;
                   }
                   break;
                
               case 2:
                   System.out.println("=== Caja cerrada. Gracias por su visita!🎀💻 ===");
                   break;
               
               default: 
                   System.out.println("Opción no valida. Porfavor intente otra vez. ✖");
      
           }
           break; 
       }
       mostrar();
    }
    
}
