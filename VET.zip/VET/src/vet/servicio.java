/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vet;

/**
 *
 * @author Maria Gabriela
 */
public class servicio extends tamano {
    //resumen del dia
    int bancantidad=0;
    int concantidad=0;
    int ocantidad=0;
    int scantidad=0;
    int mcantidad=0;
    int bcantidad=0;

    public int getBancantidad() {
        return bancantidad;
    }

    public void setBancantidad(int bancantidad) {
        this.bancantidad = bancantidad;
    }

    public int getConcantidad() {
        return concantidad;
    }

    public void setConcantidad(int concantidad) {
        this.concantidad = concantidad;
    }

    public int getOcantidad() {
        return ocantidad;
    }

    public void setOcantidad(int ocantidad) {
        this.ocantidad = ocantidad;
    }

    public int getScantidad() {
        return scantidad;
    }

    public void setScantidad(int scantidad) {
        this.scantidad = scantidad;
    }

    public int getMcantidad() {
        return mcantidad;
    }

    public void setMcantidad(int mcantidad) {
        this.mcantidad = mcantidad;
    }

    public int getBcantidad() {
        return bcantidad;
    }

    public void setBcantidad(int bcantidad) {
        this.bcantidad = bcantidad;
    }
    
    
}
